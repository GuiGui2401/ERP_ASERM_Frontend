import Main from "./Main";

function Home() {
  return (
    <Main>
      <h2 className='dashboard'>DashBoard</h2>
    </Main>
  );
}

export default Home;
