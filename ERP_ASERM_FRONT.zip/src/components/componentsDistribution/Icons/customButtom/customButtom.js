// import {
//     WhatsAppOutlined,
//     MessageOutlined,
//     NotificationOutlined
//   } from "@ant-design/icons";

//   import { FloatButton } from "antd";
  
//   const customButtom = () => {
//     return (
//         <>
//         <FloatButton.Group
//           trigger="hover"
//           type="primary"
//           icon={<NotificationOutlined />}
//           tooltip={<div>contacter par</div>}
//           badge={{ count: 2, color: "yellow" }}
//         >
//           <FloatButton
//             badge={{ dot: true, color: "green" }}
//             icon={<WhatsAppOutlined />}
//             tooltip={<div>whatapp</div>}
//           />
//           <FloatButton
//             icon={<MessageOutlined />}
//             tooltip={<div>sms</div>}
//             badge={{ dot: true }}
//           />
//         </FloatButton.Group>
//       </>
//     )
//   }
  
//   export default customButtom;
  